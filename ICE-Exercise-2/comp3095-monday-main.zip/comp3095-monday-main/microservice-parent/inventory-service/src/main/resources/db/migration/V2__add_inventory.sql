INSERT INTO t_inventory(quantity, sku_code)
VALUES
    (100, 'SKU_001'),
    (200, 'SKU_002'),
    (300, 'SKU_003'),
    (400, 'SKU_004'),
    (500, 'SKU_005');