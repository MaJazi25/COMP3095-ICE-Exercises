CREATE DATABASE inventory_service;
CREATE USER admin WITH PASSWORD 'password';
GRANT ALL PRIVILEGES ON DATABASE inventory_service TO admin;